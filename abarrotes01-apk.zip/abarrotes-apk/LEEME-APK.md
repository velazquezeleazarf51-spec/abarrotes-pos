# Abarrotes POS – APK (sin navegador)

La app va empaquetada dentro del APK (Capacitor). GitHub compila el APK solo.
Nombre: **Abarrotes POS** · ID: `com.abarrotespos.app` (cámbialo en `capacitor.config.json` ANTES del primer APK que instales; después ya no).

## 1. Crear tu llave de firma (una sola vez, en tu PC)

Necesitas Java instalado (comando `keytool`).

    keytool -genkeypair -v -keystore abarrotes.jks -alias abarrotes -keyalg RSA -keysize 2048 -validity 10000 -storetype PKCS12

Te pide una contraseña (anótala). **Guarda `abarrotes.jks` y la contraseña en 2 lugares seguros fuera de GitHub.**
Si los pierdes, no podrás actualizar la app en los teléfonos ya instalados.

Convierte la llave a texto:
- Linux/Mac: `base64 -w0 abarrotes.jks`
- Windows (PowerShell): `[Convert]::ToBase64String([IO.File]::ReadAllBytes("abarrotes.jks"))`

## 2. Subir a GitHub

1. Crea un repositorio **privado** y sube TODO el contenido de esta carpeta (incluida `.github`).
2. Settings → Secrets and variables → Actions → New repository secret. Crea 3:
   - `KEYSTORE_BASE64` → el texto largo del paso anterior
   - `KEYSTORE_PASSWORD` → la contraseña
   - `KEY_ALIAS` → `abarrotes`

## 3. Descargar el APK

Pestaña **Actions** → "Build APK" → entra a la ejecución → abajo, **Artifacts** → `abarrotes-pos-apk`.
Cada vez que subas cambios a `main` se genera un APK nuevo (también puedes pulsar "Run workflow").
Si no pusiste los secrets, genera un APK de prueba `...-DEBUG.apk` (sirve para probar, no para repartir).

## 4. Instalar en los teléfonos

Pasa el APK por WhatsApp/Drive/USB y ábrelo; Android pedirá permitir "instalar apps desconocidas".

## Qué cambia respecto a la web

- **Descargas** (CSV, respaldo JSON, imagen de código): abren el menú *Compartir* para guardarlas o enviarlas.
- **Imprimir etiquetas**: genera un **PDF** y abre *Compartir*.
- Los datos viven en cada teléfono (no se sincronizan). Desinstalar la app o borrar sus datos los borra: haz **respaldos** seguido.
- Contraseña inicial: `1234`.

## Si el workflow falla

Abre la ejecución en Actions, copia las últimas líneas del paso en rojo y envíamelas.
