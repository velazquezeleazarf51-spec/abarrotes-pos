/* Puente para el APK (Capacitor).
   - Las descargas (CSV, respaldo JSON, PNG de código) se guardan y se abren en "Compartir".
   - "Imprimir" genera un PDF de las etiquetas y lo abre en "Compartir".
   En un navegador normal no hace nada. */
(function () {
  'use strict';
  var cap = window.Capacitor;
  var isNative = !!(cap && cap.isNativePlatform && cap.isNativePlatform());
  if (!isNative) return;

  function plugin(name) {
    var p = cap.Plugins && cap.Plugins[name];
    if (!p) throw new Error('Plugin ' + name + ' no disponible');
    return p;
  }

  function blobToBase64(blob) {
    return new Promise(function (resolve, reject) {
      var r = new FileReader();
      r.onload = function () { resolve(String(r.result).split(',')[1] || ''); };
      r.onerror = function () { reject(r.error || new Error('No se pudo leer el archivo')); };
      r.readAsDataURL(blob);
    });
  }

  async function shareBase64(filename, base64, title) {
    var safe = String(filename || 'archivo').replace(/[^\w.\-]+/g, '_');
    var res = await plugin('Filesystem').writeFile({
      path: safe,
      data: base64,
      directory: 'CACHE'
    });
    await plugin('Share').share({
      title: title || safe,
      url: res.uri,
      dialogTitle: 'Guardar o compartir'
    });
  }
  window.nativeShareBase64 = shareBase64;

  // ---------- Descargas: a.download + a.click() ----------
  var origClick = HTMLAnchorElement.prototype.click;
  HTMLAnchorElement.prototype.click = function () {
    var a = this;
    if (a.hasAttribute('download') && a.href) {
      (async function () {
        try {
          var blob = await (await fetch(a.href)).blob();
          await shareBase64(a.getAttribute('download'), await blobToBase64(blob));
        } catch (e) {
          if (!/cancel/i.test(String(e && e.message))) {
            alert('No se pudo guardar el archivo: ' + (e && e.message ? e.message : e));
          }
        }
      })();
      return;
    }
    return origClick.apply(this, arguments);
  };

  // ---------- Imprimir => PDF ----------
  // Reutiliza las reglas @media print de la app para que el PDF se vea igual que la hoja impresa.
  function printCss() {
    var css = '';
    Array.prototype.forEach.call(document.styleSheets, function (sheet) {
      var rules;
      try { rules = sheet.cssRules; } catch (e) { return; }
      Array.prototype.forEach.call(rules, function (rule) {
        if (rule.type === 4 && rule.media && /print/.test(rule.media.mediaText)) {
          Array.prototype.forEach.call(rule.cssRules, function (r) {
            var sel = r.selectorText || '';
            if (sel.indexOf('body *') === 0 || sel.indexOf('#print-area') === 0) return;
            css += r.cssText + '\n';
          });
        }
      });
    });
    return css;
  }

  async function printToPdf() {
    var area = document.getElementById('print-area');
    if (!area || !area.innerHTML.trim()) return;
    if (!window.jspdf || !window.html2canvas) { alert('Falta la librería de PDF.'); return; }

    var MARGIN = 8, PAGE_W = 210, PAGE_H = 297;
    var CONTENT_W = PAGE_W - MARGIN * 2, CONTENT_H = PAGE_H - MARGIN * 2;

    var style = document.createElement('style');
    style.textContent = printCss();
    document.head.appendChild(style);

    var host = document.createElement('div');
    host.style.cssText = 'position:absolute;left:-10000px;top:0;width:' + CONTENT_W +
      'mm;background:#fff;color:#000;font-family:Arial,Helvetica,sans-serif;';
    host.innerHTML = area.innerHTML;
    document.body.appendChild(host);

    try {
      await new Promise(function (r) { setTimeout(r, 150); });

      var hostTop = host.getBoundingClientRect().top;
      var cssW = host.offsetWidth;
      var tops = [];
      Array.prototype.forEach.call(host.querySelectorAll('.label-item'), function (el) {
        var t = Math.round(el.getBoundingClientRect().top - hostTop);
        if (tops.indexOf(t) === -1) tops.push(t);
      });
      tops.sort(function (a, b) { return a - b; });

      var canvas = await window.html2canvas(host, {
        scale: 2,
        backgroundColor: '#ffffff',
        logging: false,
        onclone: function (doc) {
          var h = doc.body.lastElementChild;
          while (h && h.style.left !== '-10000px') h = h.previousElementSibling;
          if (h) h.style.left = '0px';
        }
      });

      var k = canvas.width / cssW;                 // px de canvas por px css
      var mmPerPx = CONTENT_W / canvas.width;
      var pageHpx = CONTENT_H / mmPerPx;
      var rowTops = tops.map(function (t) { return t * k; });

      var pdf = new window.jspdf.jsPDF({ unit: 'mm', format: 'a4' });
      var y = 0, first = true;
      while (y < canvas.height - 1) {
        var end = Math.min(y + pageHpx, canvas.height);
        if (end < canvas.height) {
          var cands = rowTops.filter(function (t) { return t > y + 5 && t <= end; });
          if (cands.length) end = Math.max.apply(null, cands);
        }
        var h = Math.max(1, Math.round(end - y));
        var slice = document.createElement('canvas');
        slice.width = canvas.width; slice.height = h;
        var ctx = slice.getContext('2d');
        ctx.fillStyle = '#fff'; ctx.fillRect(0, 0, slice.width, slice.height);
        ctx.drawImage(canvas, 0, Math.round(y), canvas.width, h, 0, 0, canvas.width, h);
        if (!first) pdf.addPage();
        pdf.addImage(slice.toDataURL('image/png'), 'PNG', MARGIN, MARGIN, CONTENT_W, h * mmPerPx);
        first = false;
        y += h;
      }

      var b64 = pdf.output('datauristring').split(',')[1];
      await shareBase64('etiquetas-' + new Date().toISOString().slice(0, 10) + '.pdf', b64, 'Etiquetas de códigos de barras');
    } catch (e) {
      if (!/cancel/i.test(String(e && e.message))) {
        alert('No se pudo crear el PDF: ' + (e && e.message ? e.message : e));
      }
    } finally {
      host.remove();
      style.remove();
    }
  }

  window.print = function () { printToPdf(); };
})();
