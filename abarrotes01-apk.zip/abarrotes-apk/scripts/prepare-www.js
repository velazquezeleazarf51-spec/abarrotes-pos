// Copia jsPDF y html2canvas desde node_modules a www/lib (se ejecuta en GitHub Actions).
const fs = require('fs');
const path = require('path');

const jobs = [
  ['node_modules/jspdf/dist/jspdf.umd.min.js', 'www/lib/jspdf.umd.min.js'],
  ['node_modules/html2canvas/dist/html2canvas.min.js', 'www/lib/html2canvas.min.js']
];
for (const [from, to] of jobs) {
  if (!fs.existsSync(from)) {
    console.error('NO EXISTE: ' + from + ' (revisa la version instalada)');
    process.exit(1);
  }
  fs.mkdirSync(path.dirname(to), { recursive: true });
  fs.copyFileSync(from, to);
  console.log('OK ' + to);
}
