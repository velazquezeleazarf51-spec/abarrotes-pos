// Ajusta el proyecto Android que genera "npx cap add android":
// permiso de camara, iconos, color de fondo/splash y numero de version.
const fs = require('fs');
const path = require('path');

const root = 'android/app/src/main';
const res = path.join(root, 'res');

// 1) Permiso de camara
const manifestPath = path.join(root, 'AndroidManifest.xml');
let m = fs.readFileSync(manifestPath, 'utf8');
if (!m.includes('android.permission.CAMERA')) {
  m = m.replace('<application',
    '<uses-permission android:name="android.permission.CAMERA" />\n' +
    '    <uses-feature android:name="android.hardware.camera" android:required="false" />\n' +
    '    <application');
  fs.writeFileSync(manifestPath, m);
  console.log('OK permiso de camara');
}

// 2) Iconos
const iconsRoot = 'android-icons';
for (const dir of fs.readdirSync(iconsRoot)) {
  const dest = path.join(res, dir);
  fs.mkdirSync(dest, { recursive: true });
  for (const f of fs.readdirSync(path.join(iconsRoot, dir))) {
    const base = f.replace(/\.png$/, '');
    for (const old of fs.readdirSync(dest)) {
      if (old.replace(/\.[^.]+$/, '') === base) fs.unlinkSync(path.join(dest, old));
    }
    fs.copyFileSync(path.join(iconsRoot, dir, f), path.join(dest, f));
  }
}
console.log('OK iconos');

// 3) Color de fondo del icono adaptativo
const bgPath = path.join(res, 'values', 'ic_launcher_background.xml');
fs.mkdirSync(path.dirname(bgPath), { recursive: true });
fs.writeFileSync(bgPath,
  '<?xml version="1.0" encoding="utf-8"?>\n<resources>\n    <color name="ic_launcher_background">#0F766E</color>\n</resources>\n');

// 4) Splash: reemplazar la imagen de Capacitor por un color liso
let removed = 0;
for (const d of fs.readdirSync(res)) {
  if (!d.startsWith('drawable')) continue;
  const p = path.join(res, d, 'splash.png');
  if (fs.existsSync(p)) { fs.unlinkSync(p); removed++; }
}
fs.mkdirSync(path.join(res, 'drawable'), { recursive: true });
fs.writeFileSync(path.join(res, 'drawable', 'splash.xml'),
  '<?xml version="1.0" encoding="utf-8"?>\n<shape xmlns:android="http://schemas.android.com/apk/res/android" android:shape="rectangle">\n    <solid android:color="#0F766E" />\n</shape>\n');
console.log('OK splash (' + removed + ' imagenes reemplazadas)');

// 5) Version (para poder actualizar encima de una instalacion anterior)
const code = process.env.VERSION_CODE;
if (code) {
  const gp = 'android/app/build.gradle';
  let g = fs.readFileSync(gp, 'utf8');
  const before = g;
  g = g.replace(/versionCode\s+\d+/, 'versionCode ' + code)
       .replace(/versionName\s+"[^"]*"/, 'versionName "1.0.' + code + '"');
  if (g === before) console.warn('AVISO: no se pudo cambiar versionCode');
  else { fs.writeFileSync(gp, g); console.log('OK versionCode ' + code); }
}
